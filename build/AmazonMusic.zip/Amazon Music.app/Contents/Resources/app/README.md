# Amazon Music Mac App

This is an electron wrapper for https://music.amazon.in/

Just added keyboard shortcuts for:

* Play/Pause
* Next
* Previous

[Download](https://raw.githubusercontent.com/scriptspry/amazon-music-mac/master/build/AmazonMusic.zip) | [Home](http://scriptspry.com/2018/03/02/amazon-music-mac-app.html)

Enjoy! See [License](LICENSE.md)
