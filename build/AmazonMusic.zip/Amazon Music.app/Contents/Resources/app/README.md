# Amazon Music Mac App

This is an electron wrapper for https://music.amazon.in/

Just added keyboard shortcuts for:

* Play/Pause
* Next
* Previous
* Search

Enjoy! See [License](LICENSE.md)
