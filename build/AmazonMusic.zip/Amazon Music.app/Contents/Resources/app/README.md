# Amazon Music Mac App

This is an electron wrapper for https://music.amazon.in/

Just added keyboard shortcuts for:

* Play/Pause
* Next
* Previous
* Search

[Download](https://raw.githubusercontent.com/scriptspry/amazon-music-mac/master/build/AmazonMusic.zip)

Enjoy! See [License](LICENSE.md)
